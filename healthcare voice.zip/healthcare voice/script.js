function startRecording() {

    if (!("webkitSpeechRecognition" in window)) {
        alert("Speech recognition is not supported.");
        return;
    }

    const recognition = new webkitSpeechRecognition();

    recognition.lang = "en-IN";
    recognition.continuous = false;

    recognition.onresult = function(event) {

        document.getElementById("notes").value =
            event.results[0][0].transcript;
    };

    recognition.start();
}

function analyzeNote() {

    const text =
        document.getElementById("notes").value;

    const words =
        text.trim() === ""
            ? 0
            : text.trim().split(/\s+/).length;

    document.getElementById("wordCount").innerText =
        "Words: " + words;

    document.getElementById("summary").innerText =
        "Summary: " +
        (text.length > 100
            ? text.substring(0, 100) + "..."
            : text);
}